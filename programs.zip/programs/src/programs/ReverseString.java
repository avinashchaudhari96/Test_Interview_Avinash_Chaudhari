package programs;

import java.util.Scanner;

public class ReverseString {
	
	public static void main(String[] ss) {
		
	
	Scanner sc= new Scanner(System.in);
	
	String name = sc.nextLine();
	System.out.println(name);
	
	//String reverse = reverseString(name);
	
	//System.out.println(reverse);
	
	}
}
