package programs;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int emp_Id=1;
		String emp_Name = "Avinash";
		String emp_city = "Pune";
		
		System.out.println("Id is" +emp_Id +"Name :- " +emp_Name +" City " +emp_city);

	}

}
