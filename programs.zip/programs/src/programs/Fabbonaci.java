package programs;

public class Fabbonaci {
	
	public static void main(String[] ss)
	{
		int num1=0;
		int num2=1;
		int number=8;
		int num3;
		
		System.out.print(+num1 + " " +num2);
		
		for(int i=2;i<number;i++)
		{
			num3=num1+num2;
			System.out.print(" " +num3);
			num1=num2;
			num2=num3;
		}
	}
}
