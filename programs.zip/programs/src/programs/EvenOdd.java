package programs;

import java.util.Scanner;

public class EvenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner (System.in);

		System.out.println("Enter the number");
		int number = sc.nextInt();
		
		//int num=10;
		for (int i=1; i<=number; i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
		

	}

}
